package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class EmartMallDAO {
	
	Connection conn;
	PreparedStatement pstmt;
	
	final String sql_insert="INSERT INTO EMARTMALL VALUES((SELECT NVL(MAX(EID),0)+1 FROM EMARTMALL),?,?,?,?)";
	final String sql_selectAll="SELECT * FROM EMARTMALL";
	final String sql_selectOne="SELECT * FROM EMARTMALL WHERE EID=?";
	final String sql_delete="DELETE FROM EMARTMALL WHERE EID=?";
	final String sql_update="UPDATE EMARTMALL SET NAME=? WHERE EID=?";
	
	/////////////////////////////////////////////////////////////////////////////////////////////
	
	// 추가
	public boolean insert(EmartMallVO vo) {
		conn = JDBCUtil.connect();
		try {
			pstmt = conn.prepareStatement(sql_insert);
			pstmt.setString(1, vo.geteCategory()); // 카테고리
			pstmt.setString(2, vo.geteName()); // 상품이름
			pstmt.setInt(3, vo.getePrice()); // 상품가격
			pstmt.setInt(4, vo.geteReview()); // 상품리뷰
			pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		} finally {
			JDBCUtil.disconnect(pstmt, conn);
		}
		return true;
	}
	
	/////////////////////////////////////////////////////////////////////////////////////////////
	
	// 목록
	public ArrayList<EmartMallVO> selectAll(EmartMallVO vo) {
		ArrayList<EmartMallVO> datas = new ArrayList<EmartMallVO>();
		conn = JDBCUtil.connect();
		
		try {
			pstmt = conn.prepareStatement(sql_selectAll);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()) {
				EmartMallVO data = new EmartMallVO();
				data.seteId(rs.getInt("eid"));
				data.seteCategory(rs.getString("ecategory"));
				data.seteName(rs.getString("ename"));
				data.setePrice(rs.getInt("eprice"));
				data.seteReview(rs.getInt("ereview"));
				datas.add(data);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			JDBCUtil.disconnect(pstmt, conn);
		}
		return datas;
	}
	
	/////////////////////////////////////////////////////////////////////////////////////////////
	
	//검색
	public EmartMallVO selectOne(EmartMallVO vo) {
		conn=JDBCUtil.connect(); // JDBCUtil을 연결
		ResultSet rs=null; // 캡슐화를 위해 의미없는 값을 넣어줌
		try {
			pstmt=conn.prepareStatement(sql_selectOne);
			pstmt.setInt(1, vo.geteId()); // 쿼리내용의 첫번째 ?에 vo의 eid를 가져오겠다
			rs=pstmt.executeQuery(); // 데이터의 자동적인 변화
			if(rs.next()) { // 만약에 값이 있다면
				EmartMallVO data=new EmartMallVO();
				data.seteId(rs.getInt("eid")); // PK값
				data.seteCategory(rs.getString("ecategory")); // 출력값으로 카테고리
				data.seteName(rs.getString("ename")); // 출력값으로 상품이름
				data.setePrice(rs.getInt("eprice")); // 상품가격
				data.seteReview(rs.getInt("ereview")); // 상품리뷰
				return data; // 보여주기위해 값을 돌려줄것이다
			}
			else {
				return null; // 그게 아니라면 null값 돌려주기
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		} finally {
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			JDBCUtil.disconnect(pstmt, conn);
		}		
	}
	
	/////////////////////////////////////////////////////////////////////////////////////////////
	
	// 삭제
	public boolean deleteEmartMall(EmartMallVO vo) {
		conn=JDBCUtil.connect();
		try {
			pstmt=conn.prepareStatement(sql_delete);
			pstmt.setInt(1, vo.geteId()); // 1번째 물음표에 eid를 가져오겠다
			int res=pstmt.executeUpdate(); // 데이터의 자동적인 변화
			if(res==0) {
				return false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		} finally {
			JDBCUtil.disconnect(pstmt, conn);
		}
		return true;
	}
	
	/////////////////////////////////////////////////////////////////////////////////////////////
	
	// 갱신
	public boolean updateEmartMall(EmartMallVO vo) {
		conn=JDBCUtil.connect();
		try {
			pstmt=conn.prepareStatement(sql_update);
			pstmt.setString(1, vo.geteName()); // 쿼리내용을 실행하기 위해 첫번째 ?에 vo의 name을 가져오겠다
			pstmt.setInt(2, vo.geteId()); // 2번째 ?에 vo의 eid를 가져오겠다
			int res=pstmt.executeUpdate(); // 데이터의 자동적인 변화
			if(res==0) {
				return false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		} finally {
			JDBCUtil.disconnect(pstmt, conn);
		}
		return true;
	}
	
	
}
