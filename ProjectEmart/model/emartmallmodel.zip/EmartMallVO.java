package model;

public class EmartMallVO {
	private int eId;
	private String eCategory;
	private String eName;
	private int ePrice;
	private int eReview;
	private String eImg;


	public int geteId() {
		return eId;
	}

	public void seteId(int eId) {
		this.eId = eId;
	}



	public String geteCategory() {
		return eCategory;
	}

	public void seteCategory(String eCategory) {
		this.eCategory = eCategory;
	}



	public String geteName() {
		return eName;
	}

	public void seteName(String eName) {
		this.eName = eName;
	}



	public int getePrice() {
		return ePrice;
	}

	public void setePrice(int ePrice) {
		this.ePrice = ePrice;
	}



	public int geteReview() {
		return eReview;
	}

	public void seteReview(int eReview) {
		this.eReview = eReview;
	}



	public String geteImg() {
		return eImg;
	}

	public void seteImg(String eImg) {
		this.eImg = eImg;
	}




	@Override
	public String toString() {
		return "이마트몰 상품PK-" + eId + ", 카테고리-" + eCategory + ", 상품이름-" + eName + ", 상품가격-" + ePrice
				+ ", 상품리뷰-" + eReview + ", 이미지-" + eImg + "]";
	}

	

	
	
}
